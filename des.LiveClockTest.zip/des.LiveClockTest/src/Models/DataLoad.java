package Models;

import Models.Reminder.Reminder;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class DataLoad {
    public static ArrayList<Event> eventList = new ArrayList<>();
    public static ArrayList<Reminder> reminderList = new ArrayList<>();
    public static User user;

    public static void loadAllData(){
        deserializeEvent();
        deserializeUser();
        deserializeReminder();
    }

    public static void saveAllData(){
        serializeEvent();
        serializeUser();
        serializeReminder();
    }

    private static void serializeUser(){    //save User data class with serialize method
        try {
            PrintWriter pw = new PrintWriter("UserSaveData.dat");
            pw.close();
            FileOutputStream fos = new FileOutputStream("UserSaveData.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(user);
            oos.close();
            fos.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }
    private static void deserializeUser(){      //load User data into User class with deserialize method
        try {
            FileInputStream fis = new FileInputStream("UserSaveData.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            user = (User) ois.readObject();
            ois.close();

            System.out.println(user);
        } catch (IOException i) {
            try {
                Files.createFile(Paths.get("UserSaveData.dat"));
            } catch (IOException io){
                io.printStackTrace();
            }
        } catch (ClassNotFoundException c) {
            System.out.println("User class not found");
        }
    }

    private static void serializeEvent(){       //save Event ArrayList class with serialize method
        try {
            PrintWriter pw = new PrintWriter("EventSaveData.dat");
            pw.close();
            FileOutputStream fos = new FileOutputStream("EventSaveData.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(eventList);
            oos.close();
            fos.close();
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    private static void deserializeEvent(){     //load list of event into Event ArrayList with deserialize method
        try {
            FileInputStream fis = new FileInputStream("EventSaveData.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            eventList = (ArrayList) ois.readObject();
            ois.close();
            fis.close();
        }
        catch (IOException ioe) {
            try {
                Files.createFile(Paths.get("EventSaveData.dat"));
            } catch (IOException io){
                io.printStackTrace();
            }
            return;
        }
        catch (ClassNotFoundException c) {
            System.out.println("Class not found");
            return;
        }

        //Verify list data
        for (Event event : eventList) {
            System.out.println(event.getTitle());
            System.out.println(event.getOwner());
            System.out.println(event.getStartTime());
            System.out.println(event.getEndTime());
            System.out.println(event.getNotiTime());
            System.out.println(event.getLocation());
            System.out.println(event.getDescription());
            System.out.println(event.getNotifyTime());
            System.out.println("########");
        }
    }
    private static void serializeReminder(){        //save Reminder ArrayList class with serialize method
        try {
            PrintWriter pw = new PrintWriter("ReminderSaveData.dat");
            pw.close();
            FileOutputStream fos = new FileOutputStream("ReminderSaveData.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(reminderList);
            oos.close();
            fos.close();
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    private  static void deserializeReminder(){        //load list of Reminder into Reminder ArrayList with deserialize method
        try {
            FileInputStream fis = new FileInputStream("ReminderSaveData.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            reminderList = (ArrayList) ois.readObject();
            ois.close();
            fis.close();
        }
        catch (IOException ioe) {
            try {
                Files.createFile(Paths.get("ReminderSaveData.dat"));
            } catch (IOException io){
                io.printStackTrace();
            }
            return;
        }
        catch (ClassNotFoundException c) {
            System.out.println("Class not found");
            c.printStackTrace();
            return;
        }
        //Verify list data
        for (Reminder reminder : reminderList) {
            System.out.println(reminder.getTitle());
            System.out.println(reminder.getTime());
            System.out.println(reminder.getRepeatType());
            System.out.println("########");
        }
    }
}
