package Models.Reminder;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Reminder implements Serializable {
    private String title;
    private String time;                // (hh:mm a dd/MM/yyyy)
    private RepeatType repeat;          // can be "None", "Daily", "Weekly", "Monthly", "Yearly", custom
    private String type;                // get type of repeat

    public String composeMessage(){
        return "Reminder " + title + " at " + time + " " + repeat.getRepeatPeriod();
    }

    public Reminder(String title, String time, RepeatType repeat){    // Create a constructor of reminder
        this.title = title;
        this.time = time;
        this.repeat = repeat;
        this.type = repeat.getRepeatPeriod();
    }

    public String getType() { //Function to return member variable type of class Reminder
        return type;
    }

    public void setType(String type) { //Function to set member variable type of class Reminder
        this.type = type;
    }

    public Reminder(String title, String time, String typeOfRepeat, String checkStr){  //Overload constructor of Reminder
        this.title = title;
        this.time = time;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a dd/MM/yyyy");
        LocalDateTime selectedTime = LocalDateTime.parse(this.time, formatter);
        boolean[] tempDay = {false,false,false,false,false,false};
        int[] tempDate = {0,0};
        if(checkStr.equals("After")){
            this.repeat = new RepeatType(1, typeOfRepeat, "never", 0, tempDay, tempDate);
        }else if (checkStr.equals("On date")){
            this.repeat = new RepeatType(1, typeOfRepeat, "never", "", tempDay, tempDate);
        } else if (checkStr.equals("Never")){
            this.repeat = new RepeatType(1,typeOfRepeat,"never",tempDay,tempDate);
        }
        this.type = repeat.getRepeatPeriod();
    }

    public String getTitle() {      // Function to get member variable "title" of class Reminder
        return title;
    }

    public void setTitle(String newTitle){      // Function to set value for member variable "title" of class Reminder
        title = newTitle;
    }

    public String getTime() {       // Function to get member variable "time" of class Reminder
        return time;
    }

    public void setTime(String newTime) { // Function to set value of member variable "time"
        time = newTime;
    }

    public RepeatType getRepeatType() { // Function to get repeat type of a reminder
        return repeat;
    }

    public void setRepeatType(RepeatType newrepeat){
        this.repeat=newrepeat;
    }

    public void setRepeatType(int repeatFrequency, String repeatPeriod, String endType, boolean[] dayOfWeek, int[] dateForMonth,int afterTimes){
        this.repeat = new RepeatType(repeatFrequency, repeatPeriod, endType, afterTimes, dayOfWeek, dateForMonth);
    }

}


