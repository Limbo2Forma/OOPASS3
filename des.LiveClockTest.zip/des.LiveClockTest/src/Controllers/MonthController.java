package Controllers;

import Models.DataLoad;
import Models.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class MonthController implements Initializable {
    private ArrayList<dayPane> allCalendarDays = new ArrayList<>(35);
    private LocalDate currentYearMonth;
    @FXML private Label yearMonth;
    @FXML private GridPane calendar;

    public class dayPane extends Pane {     //day class used to display Day in each grid Pane
        private LocalDate date;
        private boolean clicked;
        public dayPane(Node... children) {
            super(children);
            this.setOnMouseClicked(e -> setHighLight());
        }
        private void setHighLight(){
            this.clicked = true;
            populateMonth();
        }
        public void setDate(LocalDate date){
            this.date = date;
        }
        public boolean getClicked(){ return this.clicked; }
        public void setClicked(boolean bool){ this.clicked = bool; }
    }

    public void initialize(URL url, ResourceBundle rb){        //initialize Month view pane method
        LocalDate today = LocalDate.of(LocalDate.now().getYear(),LocalDate.now().getMonth(),1);
        currentYearMonth = LocalDate.now();
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 7; j++) {
                dayPane day = new dayPane();
                day.setPrefSize(156,103);
                calendar.add(day,j,i);
                allCalendarDays.add(day);
            }
        }
        findFirstSunday(today);
    }
    @FXML
    private void nextMonth(){       //switch to next month view
        currentYearMonth = currentYearMonth.plusMonths(1);
        populateMonth();
    }
    @FXML
    private void prevMonth(){       //switch to prev month view
        currentYearMonth = currentYearMonth.minusMonths(1);
        populateMonth();
    }
    private void findFirstSunday(LocalDate firstSun){
        //find first sunday of the month and repopulate month from on
        while (!firstSun.getDayOfWeek().toString().equals("SUNDAY")) {
            firstSun = firstSun.minusDays(1);
        }
        int i = 0;
        for (dayPane date: allCalendarDays) {
            while (date.getChildren().size() != 0) {
                date.getChildren().remove(0);
            }
            date.setStyle("-fx-background-color: #ffffff");
            date.setStyle("-fx-border-color: #000000");
            date.setStyle("-fx-border-width: 1px");
            LocalDate setDay = firstSun.plusDays(i);
            Label label = dayLabel(setDay);
            Label event = eventLabel(setDay);
            date.setDate(setDay);
            if (date.getClicked()){
                label.setTextFill(Color.WHITE);
                event.setTextFill(Color.WHITE);
                date.setStyle("-fx-background-color: #6699ff");
                date.setClicked(false);
            }
            date.getChildren().addAll(label,event);
            i++;
        }
        yearMonth.setText(currentYearMonth.getMonth() + " " + currentYearMonth.getYear());
    }
    //fill to set today date is red color distinct with other date
    private Label dayLabel(LocalDate date){
        Label day = new Label("" + date.getDayOfMonth());
        day.setLayoutX(5.0);
        day.setLayoutY(5.0);
        day.setFont(Font.font(null, FontWeight.BOLD,15));
        if (date.isEqual(LocalDate.now())){
            day.setTextFill(Color.RED);
        }
        return day;
    }
    private Label eventLabel(LocalDate date){
        String names = "";
        for (Event event: DataLoad.eventList) {
            if (date.isEqual(LocalDate.parse(event.getStartTime(), DateTimeFormatter.ofPattern("hh:mm a dd/MM/yyyy")))){
                names = names + event.getTitle() + "\n";
            }
        }
        Label event = new Label("" + names);
        event.setLayoutX(5.0);
        event.setLayoutY(22.0);
        return event;
    }

    //set month to populate the grid pane
    private void populateMonth(){
        LocalDate firstSun = LocalDate.of(currentYearMonth.getYear(),currentYearMonth.getMonth(),1);
        findFirstSunday(firstSun);
    }
}
