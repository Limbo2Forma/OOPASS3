package Controllers;

import Models.DataLoad;
import Models.DatePickerFormat;
import Models.Event;
import Models.Notification;
import Models.Reminder.Reminder;
import Models.Reminder.RepeatType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainMenu {
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a dd/MM/yyyy");
    private String errorMessage = "";
    private Notification notification = new Notification();
    private int number;
    private boolean isAdd,isAddReminder;
    private DatePickerFormat dpf = new DatePickerFormat();

    //main menu UI and pane properties
    @FXML private TabPane tabPane;
    @FXML private Pane mainPane;
    @FXML private MenuButton menu;
    @FXML private Tab detailEventTab,eventTab,reminderTab,detailReminder;

    //view all event and reminder  table properties
    @FXML private TableColumn eventCol, ownerCol, timeCol;
    @FXML private TableColumn reminderCol, timeRCol, repeatCol;
    @FXML public TableView<Event> eventTable;
    @FXML public TableView<Reminder> reminderTable;
    @FXML private Button createButton;

    //view detail event properties
    @FXML private ComboBox startHrs, endHrs, startAmPm, endAmPm;
    @FXML private DatePicker startDate, endDate;
    @FXML private TextArea locate, email, description;
    @FXML private TextField eventTitle, owner, notiMin;
    @FXML private Button updateAndAdd, deleteEvent;

    //view detail reminder properties
    @FXML private TextField titleField;
    @FXML private DatePicker datePicker;
    @FXML private ComboBox timeMenuButton, ampmComboBox;
    @FXML private MenuButton repeatMenuButton;
    @FXML private Label reminderLabel;

    public static RepeatType customReminder;

    @FXML
    public void initialize() throws Exception {     //initialize all elements in menu, tables, calendar,...
        menu.setText("Weekly");
        mainPane.getChildren().add(FXMLLoader.load(getClass().getResource("/Views/weekCalendar.fxml")));
        initializeEventTable();
        initializeReminderTable();
        refreshEventTable();
        refreshReminderTable();
    }

    private void initializeEventTable(){    //initialize event table view
        this.eventCol.setCellValueFactory(new PropertyValueFactory<Event,String>("title"));
        this.timeCol.setCellValueFactory(new PropertyValueFactory<Event,String>("startTime"));
        this.ownerCol.setCellValueFactory(new PropertyValueFactory<Event,String>("owner"));
        eventTable.setItems(getEvent());
        dpf.setDatePickerFormat(startDate);
        dpf.setDatePickerFormat(endDate);
    }
    private void initializeReminderTable(){     //initialize reminder table view
        this.reminderCol.setCellValueFactory(new PropertyValueFactory<Reminder,String>("title"));
        this.timeRCol.setCellValueFactory(new PropertyValueFactory<Reminder,String>("time"));
        this.repeatCol.setCellValueFactory(new PropertyValueFactory<Reminder,String>("type"));
        reminderTable.setItems(getReminder());
    }

    private void loadDetailEvent(){     //load event detail pane
        updateAndAdd.setDisable(false);
        if (isAdd){
            eventTitle.setText("");
            owner.setText("");
            email.setText("");
            locate.setText("");
            description.setText("");
            notiMin.setText("0");
            startHrs.setValue("");
            endHrs.setValue("");
            startAmPm.setValue("");
            endAmPm.setValue("");
            startDate.setValue(null);
            endDate.setValue(null);
        } else {
            Event event = DataLoad.eventList.get(number);
            String[] start = event.getStartTime().split(" ");
            String[] end = event.getStartTime().split(" ");
            eventTitle.setText(event.getTitle());
            owner.setText(event.getOwner());
            email.setText(event.getGuestList());
            locate.setText(event.getLocation());
            description.setText(event.getDescription());
            notiMin.setText(event.getNotiTime() + "");
            startHrs.setValue(start[0]);
            endHrs.setValue(end[0]);
            startAmPm.setValue(start[1]);
            endAmPm.setValue(end[1]);
            startDate.setValue(LocalDate.parse(start[2],DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            endDate.setValue(LocalDate.parse(end[2],DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        }
    }

    @FXML private void showSetting()throws Exception{       //load and show setting pop up
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/setting.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Setting");
        stage.setResizable(false);
        stage.setScene(new Scene(root));
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.showAndWait();
    }

    @FXML
    private void showMonth() throws Exception{      //show month view calendar
        mainPane.getChildren().clear();
        menu.setText("Monthly");
        mainPane.getChildren().add(FXMLLoader.load(getClass().getResource("/Views/monthCalendar.fxml")));
    }
    @FXML
    private void showWeek() throws Exception{       //show week view calendar
        mainPane.getChildren().clear();
        menu.setText("Weekly");
        mainPane.getChildren().add(FXMLLoader.load(getClass().getResource("/Views/weekCalendar.fxml")));
    }

    private ObservableList<Event> getEvent(){ return FXCollections.observableArrayList(); }
    private ObservableList<Reminder> getReminder(){ return FXCollections.observableArrayList(); }

    private void refreshEventTable(){       //refresh event table view
        eventTable.getItems().clear();
        for (Event event: DataLoad.eventList) {
            eventTable.getItems().add(event);
        }
    }

    private void refreshReminderTable(){    //refresh reminder table
        reminderTable.getItems().clear();
        for (Reminder reminder: DataLoad.reminderList) {
            reminderTable.getItems().add(reminder);
        }
    }

    public void deleteEventAll(){       //delete event from table view
        ObservableList<Event> selectedEvents, allEvents;
        allEvents = eventTable.getItems();
        selectedEvents = eventTable.getSelectionModel().getSelectedItems();

        for (Event event : selectedEvents){
            int i = eventTable.getSelectionModel().getFocusedIndex();
            allEvents.remove(event);
            System.out.println(i);
            System.out.println(DataLoad.eventList.get(i).getTitle());
            DataLoad.eventList.remove(i);
            DataLoad.eventList.trimToSize();
        }
        exitUpdateOrAdd();
    }
    private void pickDetailEvent(){     //switch to detail event pane
        detailEventTab.setDisable(false);
        eventTab.setDisable(true);
        reminderTab.setDisable(false);
        detailReminder.setDisable(true);
        tabPane.getSelectionModel().select(1);
    }


    @FXML
    private void updateEventAll(){      //switch to editing event pane (sub pane of detail event pane)
        pickDetailEvent();
        number = eventTable.getSelectionModel().getFocusedIndex();
        System.out.println(number);
        updateAndAdd.setText("Update");
        isAdd = false;
        deleteEvent.setText("Delete");
        loadDetailEvent();
    }

    @FXML
    private void addEventAll(){     //switch to add new event pane (sub pane of detail event pane)
        pickDetailEvent();
        updateAndAdd.setText("Add");
        isAdd = true;
        deleteEvent.setText("Cancel");
        loadDetailEvent();
    }

    @FXML
    private void updateAndAddEvent(){     //register updated/newly added Event into ArrayList
        //get event title
        String title = eventTitle.getText();
        if (title.equals("")){      //error msg if blank
            this.errorMessage = this.errorMessage + "Missing Event Title\n\n";
        }
        //get event owner
        String owner = this.owner.getText();
        if (owner.equals("")){      //error msg if blank
            owner = DataLoad.user.name;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        //get event start time, default date is today (as we choose the date to start event)
        String startTime = "";
        LocalDateTime start = null;
        try {
            startTime = startHrs.getValue() + " " + startAmPm.getValue()
                    + " " + startDate.getValue().format(formatter);
            start = LocalDateTime.parse(startTime, this.formatter);
            if (start.isBefore(LocalDateTime.now().withNano(0).withSecond(0))){
                //error msg if start date is sooner than today
                this.errorMessage = this.errorMessage + "Invalid start time input\n" +
                        "It should start after right now, duh.\n\n";
            }
        } catch (Exception e){      //error msg if wrong format input or no input
            this.errorMessage = this.errorMessage + "Invalid start time input\n" +
                    "Please check if hours input are correct, include AM/PM.\n\n";
        }
        //get event location, if user let blank, fill as none
        String location = locate.getText();
        if (location.equals("")){
            location = "None";
        }
        //get event description, if user let blank, fill as none
        String describe = description.getText();
        if (describe.equals("")){
            describe = "None";
        }
        //get notification time before event
        int notiTime = 0;
        try {
            notiTime = Integer.parseInt(notiMin.getText());
        } catch (NumberFormatException e){
            this.errorMessage = this.errorMessage + "Invalid notification minute format.\n\n";
        }
        String endTime = "";
        try{
            endTime = endHrs.getValue() + " " + endAmPm.getValue() + " "
                    + endDate.getValue().format(formatter);
            LocalDateTime end = LocalDateTime.parse(endTime, this.formatter);
            if (end.isBefore(start)){   //error msg if end date is sooner than start date
                this.errorMessage = this.errorMessage + "Invalid end time input\n" +
                        "It should after start date, duh.\n\n";
            }

        } catch (Exception e){  //error msg if wrong format input or no input
            this.errorMessage = this.errorMessage + "Invalid end time input\n" +
                    "Please check if hours input are correct, include AM/PM.\n\n";
        }
        String guestList = email.getText();  //not have yet currently, add owner mail into the list also
        if (!notification.checkMultiEmail(guestList) && !guestList.equals("")){
            this.errorMessage = this.errorMessage + "Invalid email address(es).\n\n";
        }

        if (this.errorMessage.equals("")){  //print out event created and add created event to arrayList
            updateAndAdd.setDisable(true);
            if (isAdd){
                DataLoad.eventList.add(new Event(title,startTime,endTime,owner,location,notiTime,guestList,describe));
                notification.sendNotification("Event Updated","Event " + title + " created successfully",false);
            } else {
                DataLoad.eventList.get(number).setTitle(title);
                DataLoad.eventList.get(number).setOwner(owner);
                DataLoad.eventList.get(number).setStartTime(startTime);
                DataLoad.eventList.get(number).setEndTime(endTime);
                DataLoad.eventList.get(number).setLocation(location);
                DataLoad.eventList.get(number).setGuestList(guestList);
                DataLoad.eventList.get(number).setDescription(describe);
                DataLoad.eventList.get(number).setNotiTime(notiTime);
                DataLoad.eventList.get(number).setNotifyTime();
                notification.sendNotification("Event Updated","Event " + title + " update successfully",false);
            }
            exitUpdateOrAdd();
        } else {
            //send pop up notification error message
            System.out.println(errorMessage);
            notification.sendNotification("Error input",errorMessage,false);
            errorMessage = "";
        }
    }

    private void exitUpdateOrAdd(){     //switch to all event table view pane
        detailEventTab.setDisable(true);
        eventTab.setDisable(false);
        reminderTab.setDisable(false);
        detailReminder.setDisable(true);
        tabPane.getSelectionModel().select(0);
        refreshEventTable();
        if (menu.getText() == "Weekly"){
        } else {
            try {
                showMonth();
            } catch (Exception ex){
                System.out.println("reshow error");
                ex.printStackTrace();
            }
        }
    }

    @FXML
    public void deleteReminderAll(){        //delete reminder from all reminder table view
        ObservableList<Reminder> selectedReminders, allReminders;
        allReminders = reminderTable.getItems();
        selectedReminders = reminderTable.getSelectionModel().getSelectedItems();

        for (Reminder reminder : selectedReminders){
            int i = eventTable.getSelectionModel().getFocusedIndex();
            allReminders.remove(reminder);
            System.out.println(i);
            System.out.println(DataLoad.reminderList.get(i).getTitle());
            DataLoad.reminderList.remove(i);
            DataLoad.reminderList.trimToSize();
        }
        exitDetailReminder();
    }

    @FXML
    public void deleteEvent(){      //delete event from detail event pane
        if (!isAdd){
            DataLoad.eventList.remove(number);
            DataLoad.eventList.trimToSize();
        }
        exitUpdateOrAdd();
    }

    private void pickDetailReminder(){      //switch to detail reminder pane
        detailEventTab.setDisable(true);
        eventTab.setDisable(false);
        reminderTab.setDisable(true);
        detailReminder.setDisable(false);
        tabPane.getSelectionModel().select(3);
    }


    @FXML
    private void updateReminderAll(){   //switch to update reminder (sub pane of detail reminder pane)
        reminderLabel.setText("Edit Reminder");
        number = reminderTable.getSelectionModel().getFocusedIndex();
        Reminder remind = DataLoad.reminderList.get(number);
        System.out.println(remind.getTitle());
        titleField.setText(remind.getTitle());
        String[] srt = remind.getTime().split(" ");
        System.out.println(remind.getTime());
        datePicker.setValue(LocalDateTime.parse(remind.getTime(),formatter).toLocalDate());
        timeMenuButton.setValue(srt[0]);
        ampmComboBox.setValue(srt[1]);
        repeatMenuButton.setText(remind.getType());
        isAddReminder = false;
        createButton.setText("Update");
        pickDetailReminder();
    }

    @FXML
    private void addReminderAll(){      //switch to add reminder (sub pane of detail reminder pane)
        titleField.setText("");
        datePicker.setValue(null);
        timeMenuButton.setValue(null);
        ampmComboBox.setValue(null);
        reminderLabel.setText("Create Reminder");
        createButton.setText("Create");
        isAddReminder = true;
        pickDetailReminder();
    }

    @FXML
    private void setRepeatMenuButtonDaily(){
        repeatMenuButton.setText("Daily");
    }
    @FXML
    private void setRepeatMenuButtonWeekly(){
        repeatMenuButton.setText("Weekly");
    }
    @FXML
    private void setRepeatMenuButtonWeekday(){
        repeatMenuButton.setText("Weekday");
    }
    @FXML
    private void setRepeatMenuButtonMonthly(){
        repeatMenuButton.setText("Monthly");
    }
    @FXML
    private void setRepeatMenuButtonYearly(){
        repeatMenuButton.setText("Yearly");
    }
    @FXML
    private void setRepeatMenuButtonCustom() throws Exception{  //custom reminder can be set, however cannot notify user right now
        repeatMenuButton.setText("Custom");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/ReminderCustomType/ReminderCustomView.fxml"));
        Parent root = fxmlLoader.load();
        Stage stage  = new Stage();
        stage.setTitle("Create Custom Reminder");
        stage.setResizable(false);
        stage.setScene(new Scene(root));
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }

    @FXML
    private void acceptButtonPressed(){     //update newly edited/added reminder (not a custom reminder)
        String timeStr = "";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            timeStr = timeMenuButton.getValue() + " " + ampmComboBox.getValue() + " " + datePicker.getValue().format(formatter);
            System.out.println(timeStr);
            LocalDateTime.parse(timeStr,this.formatter);
        } catch (Exception e){
            e.printStackTrace();
            errorMessage = errorMessage + "Unspecified Date or Time";
        }
        if(!repeatMenuButton.getText().equals("Custom")){
            if(errorMessage.equals("")) {
                try {
                    System.out.println("save reminder");
                    RepeatType newRepeat = new RepeatType(repeatMenuButton.getText());
                    if (isAddReminder) {
                        DataLoad.reminderList.add(new Reminder(titleField.getText(), timeStr, newRepeat));
                    } else {
                        DataLoad.reminderList.get(number).setTitle(titleField.getText());
                        DataLoad.reminderList.get(number).setTime(timeStr);
                        DataLoad.reminderList.get(number).setRepeatType(newRepeat);
                        DataLoad.reminderList.get(number).setType(newRepeat.getRepeatPeriod());
                    }
                    refreshReminderTable();
                } catch (Exception e) {
                    System.out.println("Error creating a Reminder");
                }
                exitDetailReminder();
            } else {
                notification.sendNotification("Error creating Reminder", errorMessage, false);
                errorMessage = "";
            }
        }
        errorMessage = "";
    }

    @FXML
    private void cancelButtonPressed(){     //cancel edit/add process and to go to table view pane
        refreshReminderTable();
        exitDetailReminder();
    }

    private void exitDetailReminder(){      //switch to reminder table view pane
        detailEventTab.setDisable(true);
        eventTab.setDisable(false);
        reminderTab.setDisable(false);
        detailReminder.setDisable(true);
        tabPane.getSelectionModel().select(2);
    }
}
