package Controllers;

import Models.DataLoad;
import Models.Notification;
import Models.User;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SettingController {
    @FXML TextField name;
    @FXML TextField mail;
    @FXML TextField pass;
    @FXML Button done;

    @FXML
    private void takeUser(){        //get user name/email/password
        // Username is used as default owner of event, email and password current do nothing but still can be stored
        Notification noti = new Notification();
        String email = mail.getText();
        if (noti.checkMultiEmail(email)) {
            if (DataLoad.user == null) {
                DataLoad.user = new User(name.getText(),email,pass.getText());
                System.out.println(DataLoad.user.name + " " + DataLoad.user.mail + " " + DataLoad.user.pass);
            } else {
                DataLoad.user.setName(name.getText());
                DataLoad.user.setMail(email);
                DataLoad.user.setPass(pass.getText());
            }
        } else {
            noti.sendNotification("Invalid user input","Invalid email",false);
        }
        Stage stage = (Stage) done.getScene().getWindow();
        stage.close();
    }
}
